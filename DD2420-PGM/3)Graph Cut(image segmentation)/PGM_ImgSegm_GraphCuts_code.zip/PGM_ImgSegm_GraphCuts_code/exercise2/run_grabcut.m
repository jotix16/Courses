    close all
% rng(42)

save_dir = 'results';
if ~exist(save_dir, 'dir')
    mkdir(save_dir)
end
addpath('images', 'maxflow', 'utils')

%%%%% Select image to segment
%%% The existing images are flower.jpg, person.jpg and soldier.jpg
%%% Feel free to add your own images and run GrabCut.
%%%%%
img_file = 'soldier.jpg';
I = imread(img_file);

%% Initialize foreground/background region with box 

%%% Bounding boxes for images
%%% box(1) = x_start, box(2) = y_start
%%% box(3) = box width, box(4) = box height
%%%
%%% Below are predefined bounding boxes for the images above.
%%% The function init_foreground_region.m lets you define your own,
%%% which is necessary any other image than those above. 
%%% Set use_box to true if you wish to use predefined boxes.
%%%%%
use_box = false;
if use_box
    if strcmp(img_file, 'flower.jpg') 
        box = [ 15, 15, 230, 160 ]; % Works for flower.jpg
    elseif  strcmp(img_file, 'person.jpg')
        box = [40, 10, 175, 190 ]; % Works for person.jpg
    elseif  strcmp(img_file, 'soldier.jpg')
        box = [5, 45, 160, 205]; % Works for soldier.jpg
    else
        box = init_foreground_region(I);
    end
else
    box = init_foreground_region(I);
end


%%% Draw bounding box to see if it looks OK.
Ibox = draw_box(I, box);
imshow(Ibox)

%%% Run GrabCut
K = 3; % Number of GMM clusters
[Igrabcut, labels] = grabcut(I, box, K, save_dir); 
