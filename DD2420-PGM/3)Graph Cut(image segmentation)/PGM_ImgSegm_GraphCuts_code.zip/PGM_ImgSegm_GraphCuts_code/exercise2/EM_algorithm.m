function [gmm] = EM_algorithm(I, K, L, T)
% Learn GMM components for a set of pixels with the EM algorithm
% Args: I = All pixels (RGB values)
%       K = Number of clusters
%       L = Number of iterations for EM 
%       T = Trimap with pixel indeces
% Returns: gmm = GMM components (means, covariance matrix, weighting coeff.)

% Store all pixels from trimap
[im_h, im_w, ~] = size(I);
Ivec = single(reshape(I, im_h*im_w, 3));
Ivec1 = Ivec(T,:);
N = size(Ivec1,1);
eps = 1e-8;

% Initialize weights, mean and covariance with Kmeans
[segm, centers] = kmeans(Ivec1, K, 'Distance', 'cityblock', 'Replicates', 5);
mu_k = centers;
Sigma = cell(K,1);
w_k = zeros(1,K);
for k = 1:K
    Sigma{k} = cov(Ivec1((segm(:) == k), :));
    w_k(k) = sum((segm(:) == k)) / numel(segm);
end

% EM algorithm
fprintf('\n EM algorithm \n')
for l = 1:L

    % E-step. Compute the responsibilities from Eq. 18.
    
    
    % M-step. Compute the means, covariances and mixture weights from Eq. 19, 20, and 21.
    
    
    fprintf('Loop %i \n', l)
end
fprintf('EM done \n')

%%% Store GMMs in struct object
gmm.mu = mu_k;
gmm.cov = Sigma;
gmm.pi = w_k;

end

