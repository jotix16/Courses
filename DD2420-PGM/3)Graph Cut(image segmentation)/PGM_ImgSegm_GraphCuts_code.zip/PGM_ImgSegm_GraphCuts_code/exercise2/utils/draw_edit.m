function Iedit = draw_edit(I, coord_fg, coord_bg)
% Draw user edit by coloring fixed foreground pixels in white and
% fixed background pixels in red.

[h, w, d] = size(I);
Ivec = reshape(I, h*w, d);
ind_fg = sub2ind(size(I), coord_fg(:,2), coord_fg(:,1));
ind_bg = sub2ind(size(I), coord_bg(:,2), coord_bg(:,1));
Ivec(ind_fg,:) = 255; 

Ivec(ind_bg,1) = 255;
Ivec(ind_bg,2:3) = 0;
Iedit = reshape(Ivec, h, w, d);

end