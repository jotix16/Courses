function new_pos = add_refined_pixels(pos)
% Add adjacent pixels to pixels in pos
% imfreehand() command in Matlab demands too much "free hand" work.

pos = uint32(round(pos));

new_pos = zeros(5*size(pos,1), 2);
count = 1;
for i = 1:size(pos, 1)
    px = pos(i,1);
    py = pos(i,2);
    
    new_pos(count, :) = [px, py];
    new_pos(count+1, :) = [px+1, py];
    new_pos(count+2, :) = [px-1, py];
    new_pos(count+3, :) = [px, py+1];
    new_pos(count+4, :) = [px, py-1];
    count= count+5;
end
new_pos = unique(new_pos, 'rows');
new_pos = new_pos(2:end,:); % Hack: Remove zeros from first row
end

