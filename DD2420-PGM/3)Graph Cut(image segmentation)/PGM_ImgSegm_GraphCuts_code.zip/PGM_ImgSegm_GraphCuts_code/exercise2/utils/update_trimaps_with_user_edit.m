function [T, alpha, T_fixed] = update_trimaps_with_user_edit(I, T, alpha, coord_fg, coord_bg)


% Update foreground
ind_fg = sub2ind(size(I), coord_fg(:,2), coord_fg(:,1));
T.f = [T.f; ind_fg];
T.f = sort(T.f);
alpha(ind_fg) = 1; 

% Update background
ind_bg = sub2ind(size(I), coord_bg(:,2), coord_bg(:,1));
T.b = [T.b; ind_bg];
T.b = sort(T.b);
alpha(ind_bg) = 0;

% Update trimap with unknowns
[~, i_fg, ~] = intersect(T.u, ind_fg);
T.u(i_fg) = [];
[~, i_fg, ~] = intersect(T.b, ind_fg);
T.b(i_fg) = [];

[~, i_bg, ~] = intersect(T.u, ind_bg);
T.u(i_bg) = [];
% pixels that are already labeled as background can get added in 
% the user editing, so use unique() command
T.b = unique(T.b);

% Extra trimap with fixed pixels
T_fixed.f = ind_fg;
T_fixed.b = ind_bg;

end