function [T, alpha] = init_trimaps(mask)
% Setup trimaps. All pixels within mask are belongs to either foreground or 
% background, so they are unknowns. All pixels outside mask belongs to
% background. Trimap for foreground pixels is initially the empty set.
%
% Args: mask = Binary image mask, 1= foreground and 0 = background
% Returns: T = Trimaps with pixel indices (struct object). 
%               T.u = unknown pixels, T.b = background pixels, 
%               T.f = fixed foreground pixels 
%      alpha = binary vector, where 1= foreground and 0 = background

[im_h, im_w] = size(mask);
alpha = reshape(mask, im_h*im_w, 1);

T.u = find(alpha);
T.b = find(1-alpha);
T.f = [];

end

