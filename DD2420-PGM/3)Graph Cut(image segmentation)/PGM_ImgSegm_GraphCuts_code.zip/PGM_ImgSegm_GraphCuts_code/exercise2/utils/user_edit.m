function all_coord = user_edit(I, mode)
% User editing after segmentation
%   I = image
%   mode = 'foreground' or 'background'
% Remember to draw slowly!

[h, w, d] = size(I);
Ivec = reshape(I, h*w, d);
edit = 1;
all_coord = [];

while edit
    imshow(reshape(Ivec, h, w, d), 'InitialMagnification', 'fit');
    title(['Edit ',mode])
    hFW = imfreehand('Closed', false);
    pos = hFW.getPosition();
    upos = add_refined_pixels(pos);
    ind = sub2ind(size(I), upos(:,2), upos(:,1)); 
    if mode == 'foreground'
        Ivec(ind,:) = 255;
    else
        Ivec(ind,1) = 255;
        Ivec(ind,2:3) = 0;
    end
    all_coord = [all_coord; upos];
    
    answer = questdlg(['Continue marking ', mode, ' pixels?'], mode, 'Yes', 'No', 'Yes');
    switch answer
        case 'Yes'
            edit = 1;
        case 'No'
            edit = 0;
    end
end

all_coord = unique(all_coord, 'rows');

end

