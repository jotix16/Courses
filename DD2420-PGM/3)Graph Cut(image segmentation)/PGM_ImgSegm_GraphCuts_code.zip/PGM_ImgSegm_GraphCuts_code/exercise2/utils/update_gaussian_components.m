function [gmm_fg, gmm_bg] = update_gaussian_components(I, T, alpha, Kvec)
% Learn GMM components for a set of pixels
% Args: I = All pixels (RGB values)
%       K = Number of clusters
%       L = Number of iterations for the EM algorithm
%       T = Trimap with pixel indeces
% Returns: gmm_fg = Estimated GMM for foreground
%          gmm_bg = Estimated GMM for background

[im_h, im_w, d] = size(I);
Ivec = single(reshape(I, im_h*im_w, 3));
K = max(Kvec);

%%% Update foreground GMM with unknown (foreground) pixels
Ivec1 = Ivec(T.u,:);
Kvec_fg = Kvec(logical(alpha));

mu = zeros(K,d);
Sigma = cell(K,1);
w_k = zeros(1,K);

for k = 1:K
    Ivec1_k = Ivec1((Kvec_fg == k),:);
    mu(k,:) = mean(Ivec1_k, 1);
    Sigma{k} = cov(Ivec1_k);
    w_k(k) = length(Ivec1_k);
end
w_k = w_k ./ sum(w_k);

%%% Store estimated GMM in struct object
gmm_fg.mu = mu;
gmm_fg.cov = Sigma;
gmm_fg.pi = w_k;

%%% Update background GMM with background pixels
Ivec1 = Ivec(T.b,:);
Kvec_bg = Kvec(logical(1-alpha));

mu = zeros(K,d);
Sigma = cell(K,1);
w_k = zeros(1,K);

for k = 1:K
    Ivec1_k = Ivec1((Kvec_bg == k),:);
    mu(k,:) = mean(Ivec1_k, 1);
    Sigma{k} = cov(Ivec1_k);
    w_k(k) = length(Ivec1_k);
end
w_k = w_k ./ sum(w_k);

%%% Store estimated GMM 
gmm_bg.mu = mu;
gmm_bg.cov = Sigma;
gmm_bg.pi = w_k;

end

