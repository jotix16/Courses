function [Kvec] = assign_gmm_components(I, T, alpha, gmm_fg, gmm_bg)
% Assign GMM components for all pixels
% Args: I = All pixels (RGB values)
%       T = Trimap (struct object)
%       alpha = Indicator of foreground (1) or background (0) pixel index
%       gmm_fg = GMM for foreground pixels
%       gmm_bg = GMM for background pixels
% Returns: Kvec = Assigned clusters for every pixel

[im_h, im_w, ~] = size(I);
Ivec = single(reshape(I, im_h*im_w, 3)); % Flattened out pixels

K = length(gmm_fg.pi); % Number of clusters
Kvec = zeros(length(Ivec),1); % Vector to store assigned clusters 
eps = 1e-8; % Small number for numerical stability 

%%% Unknown (foreground) pixels
Ivec1 = Ivec(T.u,:);
prob = zeros(length(Ivec1),K);
for k = 1:K
    prob(:,k) = mvnpdf(Ivec1, gmm_fg.mu(k,:), gmm_fg.cov{k}) + eps;
end
logl_fg = bsxfun(@plus, -log(prob), -log(gmm_fg.pi));
[~,I] = min(logl_fg, [], 2);
Kvec(logical(alpha)) = I;

%%% Background pixels
Ivec1 = Ivec(T.b,:);
prob = zeros(length(Ivec1),K);
for k = 1:K
    prob(:,k) = mvnpdf(Ivec1, gmm_bg.mu(k,:), gmm_bg.cov{k}) + eps;
end
logl_bg = bsxfun(@plus, -log(prob), -log(gmm_bg.pi));
[~,I] = min(logl_bg, [], 2);
Kvec(logical(1-alpha)) = I;

end

