function [box] = init_foreground_region(I)
% Grab foreground region with bounding box
% Args: 
%    I: Image pixels (RBG values)
% Returns: 
%    box: [xmin ymin width height]

done = false;
figure
while ~done
    imshow(I, 'InitialMagnification','fit')
    title('Draw bounding box around object by using the mouse button.')
    box = getrect;
    box = round(box);

    Itmp = draw_box(I, box);
    imshow(Itmp, 'InitialMagnification', 'fit')
    title({'Press the mouse button to continue or any key','to select a new box.'})

    w = waitforbuttonpress;
    if w == 0 % mouse button press
        done = true;
    end
end
close 
end

