function [Isegm] = grabcut_segment(I, labels)
% Get segmentation made by GrabCut
% Args: I = All pixels (RGB values)
%       labels = binary labeling, foreground as 1 and background as 0
% Returns: Isegm = Segmentation of image

[h, w, d] = size(I);
I = single(I);
labels = single(labels);
I(:,:,1) = I(:,:,1).*labels;
I(:,:,2) = I(:,:,2).*labels;
I(:,:,3) = I(:,:,3).*labels;

Ivec = reshape(I, h*w, d);
Ivec((Ivec(:,1) == 0),:) = 255; % Color background pixels as white
Isegm = reshape(Ivec, h, w, d);
Isegm = uint8(Isegm);
end

