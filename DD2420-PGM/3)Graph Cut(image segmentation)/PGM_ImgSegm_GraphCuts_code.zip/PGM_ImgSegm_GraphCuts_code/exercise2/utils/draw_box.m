function Itmp = draw_box(I, box)

xi = box(1);
yi = box(2);
width = box(3);
height = box(4);
Itmp = I;

% Upper horizontal line
Itmp(yi, xi:(xi+width), :) = 0;
Itmp(yi, xi:(xi+width), 1) = 255;

% Left vertical line
Itmp(yi:(yi+height), xi, :) = 0;
Itmp(yi:(yi+height), xi, 1) = 255;

% Lower horizontal line
Itmp((yi+height), xi:(xi+width), :) = 0;
Itmp((yi+height), xi:(xi+width), 1) = 255;

% Right vertical line
Itmp(yi:(yi+height), (xi+width), :) = 0;
Itmp(yi:(yi+height), (xi+width), 1) = 255;

end

