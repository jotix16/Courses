function A = compute_unary_terms(I, gmm_fg, gmm_bg)
% Assign weights to each pixel according to if they belong to foreground or
% background
% Args: I = All pixels (RGB values)
%       fmm_fg = Foreground GMM
%       gmm_bg = Background GMM
% Returns: A = Unary terms in sparse matrix 

[im_h, im_w, ~] = size(I);
Ivec = single(reshape(I, im_h*im_w, 3));
K = length(gmm_fg.pi);

%%% Compute negative log-likelihood for all pixels with foreground GMM
logl_fg = 0;

%%% Compute negative log-likelihood for all pixels with background GMM
logl_bg = 0;

A = sparse([logl_fg, logl_bg]);
end

