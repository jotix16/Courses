function [ Igrab, labels ] = grabcut(I, box, K, save_dir)
% The GrabCut algorithm

save = true; % Save segmentations?

[h,w,~] = size(I);
%%% Create mask for fetching foreground/background pixels %%%
dw = box(3) + 1;
dh = box(4) + 1;
mask = uint8([zeros(box(2)-1,w); zeros(dh,box(1)-1), ones(dh,dw), ...
	     zeros(dh,w-box(3)-box(1)); zeros(h-box(4)-box(2),w)]);

%%% Initialization %%%
[T, x] = init_trimaps(mask);

%%% EM algorithm %%%
fprintf('Find Gaussian mixture models...\n');
gmm_fg = EM_algorithm(I, K, 8, T.u);
gmm_bg = EM_algorithm(I, K, 8, T.b);


%%% Compute pairwise costs %%%
gamma= 50;
pairwise_terms = compute_pairwise_terms(I, gamma);

%%% Iterative Minimization
% You may stop the iterative scheme until it has converged by checking
% the flow value. Run it for some iterations works fine too.
n_iter = 3;
for l=1:n_iter

    fprintf('Iteration %d \n',l);
    % Assign pixels to GMM clusters
    Kvec = assign_gmm_components(I, T, alpha, gmm_fg, gmm_bg);
    
    % Update GMM components with pixels assigned to each GMM and cluster
    [gmm_fg, gmm_bg] = update_gaussian_components(I, T, alpha, Kvec);
    
    % Assign foreground and background weights
    unary_terms = compute_unary_terms(I, gmm_fg, gmm_bg);
    
    % Run graph cuts
    [flow, labels] = maxflow(pairwise_terms, unary_terms);
    fprintf('Max flow value: %f \n', flow)
    
    % Update trimaps and alpha
    alpha_old = alpha;
    alpha = double(labels(:));
    T.u = find(alpha == 1);
    T.b = find(alpha == 0);
    fprintf('Pixels changed: %d \n', sum(abs(double(alpha)-double(alpha_old))))

end

%%% Display segmentation
labels = reshape(labels, h, w);
Igrab = grabcut_segment(I, labels);
figure(1)
imshow(Igrab, 'InitialMagnification', 'fit');
if save
    savefig([save_dir,'/segmentation1'])
end

%%% User Editing
% Draw by pressing the mouse button. You will fix more pixels by moving
% the mouse slowly. 
%
% Note that this window pops up in front of the segmented result, so it 
% is possible while editing to check which parts that belong to the 
% foreground or background. 
%%%
%%% User Editing
answer = questdlg('User editing?', '', 'Yes', 'No', 'Yes');
switch answer
    case 'Yes'
        fprintf('\nRefine operation \n')
        figure(2)
%         done = false;
        coord_fg = user_edit(I, 'foreground');
        coord_bg = user_edit(I, 'background');
        close all
        
        Iedit = draw_edit(I, coord_fg, coord_bg);
        if save
            figure
            imshow(Iedit, 'InitialMagnification', 'fit')
            savefig([save_dir,'/user_edit'])
            close
        end
        
        alpha_old = alpha;
        [~, alpha, T_fixed] = update_trimaps_with_user_edit(I, T, alpha, coord_fg, coord_bg);
        fprintf('Pixels changed: %d \n', sum(abs(double(alpha)-double(alpha_old))));
        
        % Update unary weights for foreground pixels
        unary_weights = compute_unary_terms(I, gmm_fg, gmm_bg);        
        unary_weights(T_fixed.f, 1) = 0;
        unary_weights(T_fixed.f, 2) = 200; % Needs to be a high value
        unary_weights(T_fixed.b, 1) = 200; % Needs to be a high value
        unary_weights(T_fixed.b, 2) = 0;

        % Run graph cuts one last time...
        [flow, labels] = maxflow(pairwise_weights, unary_weights);
        fprintf('Max flow value: %f \n', flow)
        alpha_old = alpha;
        alpha = double(labels(:));
        fprintf('Pixels changed: %d \n', sum(abs(double(alpha)-double(alpha_old))));
        
        % Save results
        labels = reshape(labels, h, w);
        Igrab = grabcut_segment(I, labels);
        figure
        imshow(Igrab, 'InitialMagnification', 'fit');
        savefig([save_dir,'/segmentation2'])
end % End of switch

end


